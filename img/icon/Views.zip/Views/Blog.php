
            <div class="page-header-area bg-img" style="background-image: url(&quot;Src/Inc/img/pagetitle-bg.jpg&quot;);">
                <div class="page-header-area-inner">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12 text-center">
                                <div class="page-header-content-inner">
                                    <div class="page-header-content">
                                        <h2>blog classic</h2>
                                        <div></div>
                                        <div class="breadcrumb-wrapper"><span><a href="/react/hireco/" title="Homepage"><i class="ti ti-home"></i>&nbsp;&nbsp;Home</a></span><span class="bread-sep">&nbsp;/&nbsp;</span>blog</div>
                                        <div></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="ttm-row sidebar ttm-sidebar clearfix">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8 content-area">
                            <article class="post ttm-blog-classic clearfix">
                                <div class="ttm-post-featured-wrapper ttm-featured-wrapper">
                                    <div class="ttm-post-featured"><img class="img-fluid" src="Src/Inc/img/blog/blog-01-1200x800.jpg" alt="blog-img">
                                        <div class="ttm-box-post-date"><span class="ttm-entry-date"><time class="entry-date">18 Mar 2020</time></span></div>
                                    </div>
                                </div>
                                <div class="ttm-blog-classic-content">
                                    <div class="ttm-post-entry-header">
                                        <div class="post-meta"><span class="ttm-meta-line category"><i class="ti ti-folder"></i>business</span><span class="ttm-meta-line byline"><i class="ti ti-user"></i>John Doe</span><span class="ttm-meta-line tags-links"><i class="far fa-comments"></i>0 Comments</span></div>
                                        <header
                                            class="entry-header">
                                            <h2 class="entry-title"><a href="/react/hireco/blog_details">How Sources Utilize Their Sleuthing Skills Beyond Work</a></h2>
                                            </header>
                                    </div>
                                    <div class="entry-content">
                                        <div class="ttm-box-desc-text">
                                            <p>If you are curious how else you could help yourself or others with sourcing abilities outside of the normal requisition- and pipelining-related works, your colleagues have recently been provided an ingenious
                                                inspiration. It used to be the third person who was able to ask him a question out!</p>
                                        </div>
                                        <div class="ttm-blogbox-footer-readmore"><a class="ttm-btn ttm-btn-size-md btn-inline ttm-btn-color-dark" href="/react/hireco/blog_details">Read More<i class="fa fa-angle-double-right"></i></a></div>
                                    </div>
                                </div>
                            </article>
                            <article class="post ttm-blog-classic clearfix">
                                <div class="ttm-post-featured-wrapper ttm-featured-wrapper">
                                    <div class="ttm-post-featured"><img class="img-fluid" src="Src/Inc/img/blog/blog-02-1200x800.jpg" alt="blog-img">
                                        <div class="ttm-box-post-date"><span class="ttm-entry-date"><time class="entry-date">18 Mar 2020</time></span></div>
                                    </div>
                                </div>
                                <div class="ttm-blog-classic-content">
                                    <div class="ttm-post-entry-header">
                                        <div class="post-meta"><span class="ttm-meta-line category"><i class="ti ti-folder"></i>business</span><span class="ttm-meta-line byline"><i class="ti ti-user"></i>John Doe</span><span class="ttm-meta-line tags-links"><i class="far fa-comments"></i>0 Comments</span></div>
                                        <header
                                            class="entry-header">
                                            <h2 class="entry-title"><a href="/react/hireco/blog_details">Let's Create Your Own Competitive News Feeder For Free</a></h2>
                                            </header>
                                    </div>
                                    <div class="entry-content">
                                        <div class="ttm-box-desc-text">
                                            <p>The Microsoft Outlook and various dedicated feed reader apps exist, and there’s even paid competitive intelligence software, but what if you wanted a free central repository built up over time that could be
                                                shared with certain colleagues? Personnel changes worthwhile for talent sourcing</p>
                                        </div>
                                        <div class="ttm-blogbox-footer-readmore"><a class="ttm-btn ttm-btn-size-md btn-inline ttm-btn-color-dark" href="/react/hireco/blog_details">Read More<i class="fa fa-angle-double-right"></i></a></div>
                                    </div>
                                </div>
                            </article>
                            <article class="post ttm-blog-classic clearfix">
                                <div class="ttm-post-featured-wrapper ttm-featured-wrapper">
                                    <div class="ttm-post-featured"><img class="img-fluid" src="Src/Inc/img/blog/blog-04-1200x800.jpg" alt="blog-img">
                                        <div class="ttm-box-post-date"><span class="ttm-entry-date"><time class="entry-date">18 Mar 2020</time></span></div>
                                    </div>
                                </div>
                                <div class="ttm-blog-classic-content">
                                    <div class="ttm-post-entry-header">
                                        <div class="post-meta"><span class="ttm-meta-line category"><i class="ti ti-folder"></i>business</span><span class="ttm-meta-line byline"><i class="ti ti-user"></i>John Doe</span><span class="ttm-meta-line tags-links"><i class="far fa-comments"></i>0 Comments</span></div>
                                        <header
                                            class="entry-header">
                                            <h2 class="entry-title"><a href="/react/hireco/blog_details">Remote Hiring Trends Report 2021: Review Hire Process</a></h2>
                                            </header>
                                    </div>
                                    <div class="entry-content">
                                        <div class="ttm-box-desc-text">
                                            <p>80% of global HR leaders reveal that their interviewing and hiring process is now fully remote. Find more trends and actionable insights in this report to learn how you can invest in a better remote hiring process
                                                today. The world and receive over 140 million unique visitors per month.</p>
                                        </div>
                                        <div class="ttm-blogbox-footer-readmore"><a class="ttm-btn ttm-btn-size-md btn-inline ttm-btn-color-dark" href="/react/hireco/blog_details">Read More<i class="fa fa-angle-double-right"></i></a></div>
                                    </div>
                                </div>
                            </article>
                            <div class="pagination-block"><span class="page-numbers current">1</span><a class="page-numbers" href="#">2</a><a class="next page-numbers" href="#"><i class="ti ti-arrow-right"></i></a></div>
                        </div>
                        <div class="col-lg-4 widget-area">
                            <div class="sidebar-right">
                                <aside class="widget widget-search">
                                    <form role="search" class="search-form"><label><span class="screen-reader-text">Search for:</span><input type="search" class="input-text" placeholder="Your Keyword...." value=""></label><button class="btn" type="submit"><i class="fa fa-search"></i> </button></form>
                                </aside>
                                <aside class="widget widget-Categories with-title">
                                    <h3 class="widget-title">Categories</h3>
                                    <ul>
                                        <li><a href="/react/hireco/blog_details">Digital Marketing</a></li>
                                        <li><a href="/react/hireco/blog_details">Search Engine Optimization</a></li>
                                        <li><a href="/react/hireco/blog_details">UI/UX Design Task</a></li>
                                        <li><a href="/react/hireco/blog_details">Web development</a></li>
                                        <li><a href="/react/hireco/blog_details">Digital Marketing</a></li>
                                        <li><a href="/react/hireco/blog_details">Investment</a></li>
                                    </ul>
                                </aside>
                                <aside class="widget widget-recent-post with-title">
                                    <h3 class="widget-title">Recent Posts</h3>
                                    <ul>
                                        <li>
                                            <a href="/react/hireco/blog_details"><img class="img-fluid" src="Src/Inc/img/blog/b_thumbb-01.jpg" alt="post-img"></a>
                                            <div class="post-detail"><a href="/react/hireco/blog_details">How Sources Utilize Sleuth Skill Beyond Work</a><span class="post-date">October 10, 2020</span></div>
                                        </li>
                                        <li>
                                            <a href="/react/hireco/blog_details"><img class="img-fluid" src="Src/Inc/img/blog/b_thumbb-02.jpg" alt="post-img"></a>
                                            <div class="post-detail"><a href="/react/hireco/blog_details">Let's Create Your Own Competitive News Feeder For Free</a><span class="post-date">October 10, 2020</span></div>
                                        </li>
                                        <li>
                                            <a href="/react/hireco/blog_details"><img class="img-fluid" src="Src/Inc/img/blog/b_thumbb-03.jpg" alt="post-img"></a>
                                            <div class="post-detail"><a href="/react/hireco/blog_details">Remote Hiring Trends Report 2021: Review Hire Process</a><span class="post-date">October 10, 2020</span></div>
                                        </li>
                                    </ul>
                                </aside>
                                <aside class="widget widget-banner">
                                    <div class="ttm-col-bgcolor-yes bg-theme-DarkColor col-bg-img-seven ttm-col-bgimage-yes ttm-bg p-30 pb-50 pt-45">
                                        <div class="ttm-col-wrapper-bg-layer ttm-bg-layer bg-theme-DarkColor" style="background-image: url(&quot;Src/Inc/img/bg-image/col-bgimage-7.jpg&quot;);">
                                            <div class="ttm-col-wrapper-bg-layer-inner bg-theme-DarkColor"></div>
                                        </div>
                                        <div class="layer-content text-center text-theme-WhiteColor">
                                            <div class="ttm-icon ttm-icon_element-onlytxt ttm-icon_element-style-round ttm-icon_element-color-skincolor ttm-icon_element-size-xl"><i class="far fa-comments"></i></div>
                                            <h3>Do You Need Any Help?</h3>
                                            <div class="ttm-horizontal_sep width-100 mt-25 mb-25"></div>
                                            <ul>
                                                <li>+1 800 556 77 894</li>
                                                <li>info@yourmailexample.com</li>
                                            </ul><a class="ttm-btn ttm-btn-size-md ttm-btn-shape-rounded ttm-btn-style-fill ttm-btn-color-skincolor" href="/react/hireco/">appoinments!</a></div>
                                    </div>
                                </aside>
                                <aside class="widget tagcloud-widget with-title">
                                    <h3 class="widget-title">Popular Tags</h3>
                                    <div class="tagcloud"><a href="/react/hireco/blog_details" class="tag-cloud-link">Agency</a><a href="/react/hireco/blog_details" class="tag-cloud-link">Business</a><a href="/react/hireco/blog_details" class="tag-cloud-link">Corporate</a>
                                        <a
                                            href="/react/hireco/blog_details" class="tag-cloud-link">Creative</a><a href="/react/hireco/blog_details" class="tag-cloud-link">Design</a><a href="/react/hireco/blog_details" class="tag-cloud-link">inspiration</a><a href="/react/hireco/blog_details" class="tag-cloud-link">Marketing</a>
                                            <a
                                                href="/react/hireco/blog_details" class="tag-cloud-link">Startup</a>
                                    </div>
                                </aside>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
          