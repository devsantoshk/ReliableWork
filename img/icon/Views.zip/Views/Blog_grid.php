<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="icon" href="https://themetechmount.com/react/hireco/favicon.ico">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="theme-color" content="#000000">
    <meta name="description" content="Recruitment Services React Template">
    <link rel="apple-touch-icon" href="https://themetechmount.com/react/hireco/logo192.png">
    <title>Recruitment Services React Template</title>
    <link href="assets/Src/Css/2.02ce4a54.chunk.css" rel="stylesheet">
    <link href="assets/Src/Css/main.b8d4d7bc.chunk.css" rel="stylesheet">
    <!-- <link href="assets/Src/Css/main.css" rel="stylesheet"> -->
    <link href="assets/Lib/themify-icons-font/themify-icons/themify-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flaticon@VERSION/style.css">
    <link rel="stylesheet" href="assets/Src/Css/_navbar.scss">
</head>

<body>

</body>

</html>