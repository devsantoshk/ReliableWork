<div id="root">
    <div class="page">
        <div class="site-main">
            <section class="error-pg text-center">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="error-type row g-0">
                                <h2 class="col">4</h2>
                                <div class="col error-icon"><img class="img-fluid bounce" src="Src/Inc/Img/error-icon.png" alt="errr-icon"></div>
                                
                                <h2 class="col">5</h2>
                            </div>
                            <header class="page-header">
                                <h1 class="page-title">Oops!</h1>
                            </header>
                            <div class="page-content">
                                <p>Page Not Found</p>
                            </div><a class="ttm-btn ttm-btn-size-md ttm-btn-shape-rounded ttm-btn-style-fill ttm-btn-color-skincolor" href="http://127.0.0.1:8080/ReliableWork/">Go back Home page</a>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>